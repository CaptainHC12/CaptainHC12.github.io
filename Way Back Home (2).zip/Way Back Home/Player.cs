﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Way_Back_Home
{
    public class Player : NPC
    {
        public string CharacterName = "";
        //public int health = 10;
        //public int Playerdamage = 3;

        public Player()
        {
            NPCName = "";
            Health = 10;
            Damage = 3;
        }


        public List<Items> Inventory = new List<Items>();

        public void dealdamage(Enemy Monster)
        {
            var random = new Random();
            int attackamount = random.Next(Damage);

            Monster.Health -= attackamount;
            
            if(Monster.Health <= 0)
            {
                Console.WriteLine("Monster disappears");
                Utulity.PressEnter();
                DropKeys();
            }

        }

        public void DropKeys()
        {
            Console.WriteLine("The monster has droped somthing\nDo you want to pick it up?");
            string input = Console.ReadLine();
            if (input.ToLower() == "yes" || input.ToLower() == "y")
            {
                Console.WriteLine("You picked up what the monster dropped.\nIt was a key.");

                Utulity.HasDropKey = true;
                Utulity.PressEnter();

            }
            else if (input.ToLower() == "no" || input.ToLower() == "n")
            {
                Console.WriteLine("You did not pick up what the monster dropped.");
                Utulity.PressEnter();
            }
            else
            {
                Console.WriteLine("You did not say yes or no\nTry again!");
                Console.ReadKey();
                Console.Clear();
                Utulity.PressEnter();
            }
        }
    }

}
