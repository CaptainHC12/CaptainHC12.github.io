﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Way_Back_Home
{
    public class Enemy : NPC
    {
        public Enemy()
        {
            NPCName = "Monster";
            Health = 8;
            Damage = 2;
        }

        //public int Enemydamage = 2;
        //public int Enemyhealth = 8;

        

        public void Dealdamage(Player attack)
        {
            var random = new Random();
            int attackamount = random.Next(Damage);

            attack.Health -= attackamount;
            Console.WriteLine("Ouch you're health is now " + attack.Health);
            Utulity.PressEnter();
            if (attack.Health <= 0)
            {
                //GameOver
                Console.WriteLine("Game Over");
                Utulity.PressEnter();

            }
        }
    }
}
