﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Way_Back_Home
{
    public class NPC
    {
        public string NPCName { get; set; }
        public int Health { get; set; }
        public int Damage { get; set; }
        
        //public string CharacterName = "";
        //public int health = 10;
        //public int Playerdamage = 3;
    }
}
