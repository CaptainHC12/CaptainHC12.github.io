﻿using System;

//Make Locaton Class
//Make Game Class
//Make Player Class
//Make Items Class
//Make Enemy class
//https://patorjk.com/software/taag/#p=display&f=Sub-Zero&t=Way%20Back%20Home%0A ASC art
//Tutor help from Mack and Grace


namespace Way_Back_Home
{
    public class Program
    {
        //Player Currentplayer = new Player();
        //Location Levels = new Location();
        static void Main()
        {
            //string[] arge

            Console.Title = "Way Back Home";

            Console.WriteLine("Welcome to way back Home");


            Game game = new Game();

            //game title

            //GameTitle();
            //CreatePlayer();
            //Levels.Level1();
            //Levels.Level2();
            //Levels.Level3();

            //Game game1 = new Game();
            game.title = "Way Back Home";
            Console.WriteLine(game.title);
            Console.ReadLine();
            Console.ReadKey();
        }

        //static void GameTitle() 
        //{

        //    //Title Name
           
        //    Console.WriteLine("Welcome to Way Back Home");
        //}

        //public void CreatePlayer()
        //{
        //    Player Currentplayer = new Player();
        //    Console.WriteLine("What is the name you want to give?");
        //    Currentplayer.CharacterName = Console.ReadLine();
        //    Console.WriteLine("Your name is " + Currentplayer.CharacterName);
        //}

    }
}
