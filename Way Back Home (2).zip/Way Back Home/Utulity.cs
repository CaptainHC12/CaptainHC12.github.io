﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Way_Back_Home
{
    public static class Utulity
    {
        public static bool HasHousePicture = false;
        public static bool HasFlashlight = false;
        public static bool HasDropKey = false;

        public static void PressEnter()
        { 
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
