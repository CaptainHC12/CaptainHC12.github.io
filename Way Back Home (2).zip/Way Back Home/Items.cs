﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Way_Back_Home
{
    public class Items
    {
        public string ItemName;
        //Items to carry and help you out
        //"Picture", "Flashlight

        public Items() { }

        public Items(string item)
        {
            ItemName = item;
        }

        //List<Items> Inventory  = new List<Items>();

    }
}

