﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Way_Back_Home
{
    public class Location
    {
        //Levels of differnt locations
        public string input;
     

        //static List<Items> Inventory = new List<Items>();

      

      
    }
}
