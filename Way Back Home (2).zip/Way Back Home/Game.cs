﻿using System;

namespace Way_Back_Home
{
    public class Game
    {
        public string gametitle = @"
 __     __     ______     __  __        ______     ______     ______     __  __        __  __     ______     __    __    ______    
/\ \  _ \ \   /\  __ \   /\ \_\ \      /\  == \   /\  __ \   /\  ___\   /\ \/ /       /\ \_\ \   /\  __ \   /\ ' -./ \  /\  ___\   
\ \ \/ '.\ \  \ \  __ \  \ \____ \     \ \  __<   \ \  __ \  \ \ \____  \ \  _'-.     \ \  __ \  \ \ \/\ \  \ \ \-./\ \  \ \  __\   
 \ \__/'.~\_\  \ \_\ \_\  \/\_____\     \ \_____\  \ \_\ \_\  \ \_____\  \ \_\ \_\     \ \_\ \_\  \ \_____\  \ \_\ \ \_\  \ \____\ 
  \/_/   \/_/   \/_/\/_/   \/_____/      \/_____/   \/_/\/_/   \/_____/   \/_/\/_/      \/_/\/_/   \/_____/   \/_/  \/_/   \/_____/";
        public string title;
        public string character;
        public string location;
        public string items;


        public string enemy;


        public Player CurrentPlayer;
        public Enemy Monster = new Enemy();

        public Location GameLocation;
        //public bool HasHousePicture = false;
        //public bool HasFlashlight = false;
        //public bool HasDropKey = false;

        public Game()
        {
            //GameTitle();
            CreatePlayer();

            GameLocation = new Location();

            Level1();
         
        }

        

        public void CreatePlayer()
        {
            //This code works if the player class isn't static

            //Player Currentplayer = new Player();
            //Console.WriteLine("What is the name you want to give?");
            //Currentplayer.CharacterName = Console.ReadLine();
            //Console.WriteLine("Your name is " + Currentplayer.CharacterName);

            Console.WriteLine("What is the name you want to give?");

            CurrentPlayer = new Player();
            CurrentPlayer.CharacterName = Console.ReadLine();
            Console.WriteLine("Your name is " + CurrentPlayer.CharacterName);
            Console.Clear();
        }

        public void Level1()
        {
            Console.Clear();
            Console.WriteLine("You seem to be lost and can't figure out how you got here.");
            Console.WriteLine("The goal is to find your way back home.");
            Console.WriteLine("Where is home you may ask? You will have to find out.");
            Console.WriteLine("You get up and start looking around. What do you need and where to go you asked yourself?");
            Utulity.PressEnter();
            Level2();
        }
        public void Level2()
        {
            Console.Clear();
            Console.WriteLine("Looking around you see something and start to move towards it.");
            Console.WriteLine("There was a sound that made you stop and wanted to see what it was.");
            Console.WriteLine("While looking around you thought to yourself it was just the wind.");
            Console.WriteLine("You found something. It's an item.");
            Console.WriteLine("Would you like to pick it up.\nYes or No?");

            string input = Console.ReadLine();
            if (input.ToLower() == "yes" || input.ToLower() == "y")
            {
                Console.WriteLine("The item was picked up.\nThe item you picked up seems to be a picture of a house.");
               

                CurrentPlayer.Inventory.Add(new Items("Picture of House"));

                Utulity.HasHousePicture = true;

            }
            else if (input.ToLower() == "no" || input.ToLower() == "n")
            {
                Console.WriteLine("You did not pick up the item.");
                Console.WriteLine("It seems that the item was not needed and you keep going.");
                
                Console.ReadKey();
            }
            else {
                Console.WriteLine("You did not say yes or no\nTry again!");
                Console.ReadKey();
                Level2();
            }
            Level3();
           
        }

        public void Level3()
        {
            Console.Clear();
           
            Console.WriteLine("Wondering if there is any thing else you need to find.");
            Console.WriteLine("The sun starts to set down and you start to noticed.");
            Console.WriteLine("You see something in the distance move. At first you wanted to know what it was but you have to get back home.");
            Console.WriteLine("You keep track of what you saw at the back of your mind and keep moving.");
            Utulity.PressEnter();
            Level4();

            
        }
        public void Level4()
        {
            Console.Clear();
            Console.WriteLine("Why hello there young one you seem to be lost.");
            Console.WriteLine("It's getting late you know. Shouldn't you be getting home?");
            Console.WriteLine("Well you see I'm trying to find my way back home and who are you?");
            Console.WriteLine("I don't think it's important to know who I am. But there is something I want to give you.");
            //Console.Clear();
            Console.WriteLine("Give me? What is there you want to give me? I don't even know you and why should I trust you?");
            Console.WriteLine("Look I know what happens around here and I wouldn't want you to get lost and hurt out here.");
            Console.WriteLine("Here take this.\nA flashlight?\nYes you're going to need it. ");
            Console.WriteLine("What for? What's the point?\nIt's to help you get back home.\nLike I said I don't want you to get lost and hurt.");
            Console.WriteLine("Would you like to take the flashlight?.\nYes or No?");

            string input = Console.ReadLine();
            if (input.ToLower() == "yes" || input.ToLower() == "y")
            {
                Console.Clear();
                Console.WriteLine("You took the flashlight from the person who wouldn't give his name.");
                Console.WriteLine("Alright I'll take it not sure how I should feel about this.");
                Console.WriteLine("So he gave me a flashlight to use to find a way out of here.");
                Console.WriteLine("I don't know why he gave me it but I might as put it to use.");
                CurrentPlayer.Inventory.Add(new Items("Flashlight"));
                Utulity.HasFlashlight = true;
                Utulity.PressEnter();
                Level5();

            }
            else if (input.ToLower() == "no" || input.ToLower() == "n")
            {
                Console.WriteLine("You did not take the flashlight.\nNo huh? I wish you luck on finding your way home then take care.");
                Console.WriteLine("Thanks for the offer but I think I'll be fine.");
                Level5();
            }
            else
            {
                Console.WriteLine("You did not say yes or no\nTry again!");
                Console.ReadKey();
                Console.Clear();
                Level4();
                Utulity.PressEnter();
            }
            
        }
        public void Level5()
        {
            Console.Clear();

            
            if (Utulity.HasFlashlight == true)
            {
                Console.WriteLine("You heard something. Might be the guy that gave you the flashlight.");
                Console.WriteLine("You use your flashlight and saw that it was him.\nAh we meet again young one and I see that flashlight came in hand.");
                Console.WriteLine("In hand? What are you talking about?\nIf you didn't take the flashlight you wouldn't have known what was coming to get you.");
                Console.WriteLine("Huh?");
                Console.Clear();
                Console.WriteLine("There are mosters around here and I seen what happened to people they never made it back.\nI gave people the flashlight and never took it. It's that important.");
                Console.WriteLine("I see I'll make sure to use when I need to.\nLOOK OUT BEHIND YOU USE YOUR FLASHLIGHT NOW!\nWhat?");
                Console.WriteLine("You used the flashlight, and the monster disappeared for now.");
            }
            else
            {
                Console.WriteLine("You didn't take the flashlight, the monster knocks you unconcious");
                Utulity.PressEnter();
                Console.WriteLine("You wake up feeling groggy and see an old man standing over you.");
                Console.WriteLine("What happened?");
                Console.WriteLine("It seems that a monster knocked you unconcious.");
                Utulity.PressEnter();
                Level4();
            }
            Utulity.PressEnter();
            Level6();
        }
        public void Level6()
        {
            Console.Clear();
            Console.WriteLine("Thanks from the man who helped you. You're not liking were you are at right now.");
            Console.WriteLine("You been looking around trying to find a way out of here.");
            Console.WriteLine("Something is coming and you feel it.\nIt's the monster from eailer it came back and it ready for round two.");
            Console.WriteLine("You are ready for it this time.\nRemember what you did to the monster with the man.");
            Console.WriteLine("The monster dropped something.");
            Utulity.PressEnter();
            EnemyInteract();
            if(Utulity.HasDropKey == true)
            {
                Console.WriteLine("You picked up what the monster dropped it was a key.");
                CurrentPlayer.Inventory.Add(new Items("DropKeys"));
            }
            Utulity.PressEnter();
            Level7();
        }
        //public void Level7()
        public void Level7()
        {
            Console.Clear();
            
            if(Utulity.HasDropKey == true && Utulity.HasHousePicture == true)
            {
                //if you get in the house
                Console.WriteLine("You're almost there and you see the house.\nYou looked at the picture and it looks the same as the house in the picture. ");
                Console.WriteLine("You got the key from the monster that dropped it from eailer and used the key to get in and you were able to find your way back home");
                Console.WriteLine("You look behind you and see the man that gave you the flashlight from eailer.");
                Console.WriteLine("It looks like he was following you to see if you got home safe.\nYou thank him and he gives a nod and goes back where he came.");
                Console.WriteLine("You got the good ending.\nGood job you made it made home.");
            }
            else
            {
                //if you fail to get in the house
                Console.WriteLine("You found you're way out and found a house.");
                Console.WriteLine("You used the key the monster dropped and tried to open it.\nIt doesn't open knowing that this key was to help you get in you didn't find the right house");
                Console.WriteLine("You did not get all the required items you needed.\nBad ending.");
                Utulity.PressEnter();
                //call the first level again
                Level1();
            }
        }

        public void EnemyInteract()
        {
            if (Utulity.HasFlashlight == true)
            {
                CurrentPlayer.dealdamage(Monster);
                Utulity.HasDropKey = true;
            }
            else
            {
                Monster.Dealdamage(CurrentPlayer);
            }
        }
    }
}
